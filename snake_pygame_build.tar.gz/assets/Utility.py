import sys
import os
import pygame
import Var
import Render
import json

def resource_path(relative_path):
    """ Get absolute path to resource, works for dev and for PyInstaller """
    try:
        # PyInstaller creates a temp folder and stores path in _MEIPASS
        base_path = sys._MEIPASS
    except Exception:
        base_path = os.path.abspath(".")

    return os.path.join(base_path, relative_path)

def update_skin(skin):
    Var.sprite_pause_button = pygame.image.load(resource_path(f"Assets/Pause.png"))
    if skin == 0:
        return
    Var.sprite_head = pygame.image.load(resource_path(f"Assets/{Var.image_folder[skin]}/Head.png")).convert_alpha()
    Var.sprite_body = pygame.image.load(resource_path(f"Assets/{Var.image_folder[skin]}/Body.png")).convert_alpha()
    Var.sprite_turn = pygame.image.load(resource_path(f"Assets/{Var.image_folder[skin]}/Turn.png")).convert_alpha()
    Var.sprite_tail = pygame.image.load(resource_path(f"Assets/{Var.image_folder[skin]}/Tail.png")).convert_alpha()
    Var.sprite_apple = pygame.image.load(resource_path(f"Assets/{Var.image_folder[skin]}/Apple.png")).convert_alpha()
    Var.sprite_bad_apple = pygame.image.load(resource_path(f"Assets/{Var.image_folder[skin]}/Bad_apple.png")).convert_alpha()
    
def hsv_to_rgb(h:float, s:float, v:float) -> tuple:
    if s:
        if h == 1.0:
            h = 0.0
        i = int(h * 6.0)
        f = h * 6.0 - i
        
        w = v * (1.0 - s)
        q = v * (1.0 - s * f)
        t = v * (1.0 - s * (1.0 - f))
        
        v *= 255
        w *= 255
        q *= 255
        t *= 255

        if i == 0: 
            return (v, t, w)
        if i == 1: 
            return (q, v, w)
        if i == 2: 
            return (w, v, t)
        if i == 3: 
            return (w, q, v)
        if i == 4: 
            return (t, w, v)
        if i == 5: 
            return (v, w, q)
    else: 
        v *= 255
        return (v, v, v)
    
def skin_selection_maker(): # set clip size to 6 x 5 then run this clip
    Var.TILE_HEIGHT = 3
    Var.TILE_WIDTH = 2
    Var.TILE_SIZE = min(500//(Var.TILE_HEIGHT + 5), 600//(Var.TILE_WIDTH + 4))
    Var.snake_body = [[1, 3], [1, 2], [1, 1], [2, 1]]
    Var.apple_x = 2
    Var.apple_y = 2
    Render.render_background()
    if Var.snake_skin > 0:
        Var.screen.blit(pygame.transform.scale(Var.sprite_bad_apple, (Var.TILE_SIZE, Var.TILE_SIZE)), [Var.left_indent + 2 * Var.TILE_SIZE + Var.TILE_SIZE/2, Var.top_indent + 3 * Var.TILE_SIZE + Var.TILE_SIZE/2])
    else:
        pygame.draw.rect(Var.screen, (133, 20, 220), [Var.left_indent + 2 * Var.TILE_SIZE + Var.TILE_SIZE/2 + Var.TILE_SIZE/6, Var.top_indent + 3 * Var.TILE_SIZE + Var.TILE_SIZE/2 + Var.TILE_SIZE/6, Var.TILE_SIZE - Var.TILE_SIZE/3, Var.TILE_SIZE - Var.TILE_SIZE/3], 0)


    pygame.display.flip()
    while True:
        for event in pygame.event.get():
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:                                
                    Var.running = False
                    Var.retry = False
                    Var.settings = False


def save_game_data():
    save_dict = {
        "high_score": Var.highScore,
        "speed": Var.speed,
        "Mode": Var.Mode,
        "challenge": Var.challenge,
        "board_height": Var.TILE_HEIGHT,
        "board_width": Var.TILE_WIDTH,
        "snake_skin": Var.snake_skin,
        "volume": Var.volume,
        "music": Var.mute_music,
        "sound_effects": Var.mute_sfx,
    }
    
    json_string = json.dumps(save_dict)
    
    if sys.platform == "emscripten":
        from platform import window
        window.localStorage.setItem("snake_save", json_string)
    else:
        with open("snake_save.json", "w") as file:
            file.write(json_string)

def load_game_data():
    json_string = None
    
    if sys.platform == "emscripten":
        from platform import window
        json_string = window.localStorage.getItem("snake_save")
    else:
        try:
            with open("snake_save.json", "r") as file:
                json_string = file.read()
        except FileNotFoundError:
            pass 
            
    if json_string:
        try:
            data = json.loads(json_string)
            
            Var.highScore = data.get("high_score", 0)
            Var.speed = data.get("speed", Var.speed)
            Var.Mode = data.get("Mode", Var.Mode)
            Var.challenge = data.get("challenge", Var.challenge)
            Var.TILE_HEIGHT = data.get("board_height", Var.TILE_HEIGHT)
            Var.TILE_WIDTH = data.get("board_width", Var.TILE_WIDTH)
            Var.snake_skin = data.get("snake_skin", Var.snake_skin)
            Var.volume = data.get("volume", Var.volume)
            Var.mute_music = data.get("music", Var.mute_music)
            Var.mute_sfx = data.get("sound_effects", Var.mute_sfx)
            
        except json.JSONDecodeError:
            print("Save data corrupted, sticking to defaults.")