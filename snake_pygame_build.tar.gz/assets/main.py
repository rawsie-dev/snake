import pygame
import random
import Var
import Utility
import States.Settings as Settings
import States.Running as Running
import States.Retry as Retry
import States.Music as Music
import States.TitleScreen as TitleScreen
import time
import gzip
import asyncio

# pygame.mixer_music.load("Assets/UnwelcomeSchool.opus")
# pygame.mixer_music.play(-1)
def init_():
    Var.dizzy = 0
    Var.applePoison = 0
    Var.appleDirection = 2  # random.randint(0, 3)
    Var.TILE_SIZE = min(500//(Var.TILE_HEIGHT + 3), 600//(Var.TILE_WIDTH + 3))
    # Var.SCREEN_WIDTH = (Var.TILE_WIDTH + 3) * Var.TILE_SIZE
    # Var.SCREEN_HEIGHT = (Var.TILE_HEIGHT + 3) * Var.TILE_SIZE + 120
    # print(Variables.SCREEN_WIDTH, Variables.SCREEN_HEIGHT)
    # Var.screen = pygame.display.set_mode((600, 600))
    Var.top_indent = (500 - Var.TILE_HEIGHT * Var.TILE_SIZE) // 2 - round(3/2 * Var.TILE_SIZE)
    Var.left_indent = (600 - Var.TILE_WIDTH * Var.TILE_SIZE) // 2 - round(3/2 * Var.TILE_SIZE)

    # print(Var.TILE_SIZE)
    Var.frame_counter = 0

    Var.snake_size = Var.TILE_SIZE
  
    Var.win_the_game = False
    Var.retry = False 

    Var.wrong_direction = 2
    Var.direction = 0
    Var.score = 0

    snake_init_x = Var.TILE_WIDTH//2
    snake_init_y = (Var.TILE_HEIGHT + 1) // 2
    if Var.TILE_WIDTH > 3:
        Var.snake_body = [[snake_init_x - i + 1, snake_init_y] for i in range(3)]
    else:
        Var.snake_body = [[3, snake_init_y], [2, snake_init_y], [1, snake_init_y]]

    # snake_init_x = 1
    # snake_init_y = 1
    # Var.snake_body = []

    # for i in range(0, 10):
    #     for j in range(0, 25):
    #         Var.snake_body.append([snake_init_x + j, snake_init_y + i * 2])
    #     if (i <= 8):
    #         for j in range(24, -1, -1):
    #             Var.snake_body.append([snake_init_x + j, snake_init_y + (i * 2 + 1)])

    Var.apple_array = []
    Var.apple_x = 1
    while Var.apple_x <= Var.TILE_WIDTH:
        Var.apple_y = 1
        while Var.apple_y <= Var.TILE_HEIGHT:
            Var.apple_array.append([Var.apple_x, Var.apple_y])
            Var.apple_y += 1
        Var.apple_x += 1

    filter_apple = [apple for apple in Var.apple_array if apple not in Var.snake_body]

    apple = random.choice(filter_apple)

    Var.apple_x = Var.snake_body[-1][0]
    Var.apple_y = Var.snake_body[-1][1]

    for i in range(6, 0, -1):
        Var.apple_x = Var.snake_body[-1][0] - i
        if Var.apple_x > 1 and [Var.apple_x, Var.apple_y] not in Var.snake_body:
            break
    else:
        Var.apple_x = apple[0]
        Var.apple_y = apple[1]
    
    Var.move_queue = []


    Utility.update_skin(Var.snake_skin)
    # Utility.skin_selection_maker()

    Var.mineList = []

    Var.radius_of_apple = Var.TILE_SIZE / 2
    Var.gamepause = False

    Var.bad_apple_frame_counter = 0
    Var.bad_apple_last_frame = -2

    Var.snake_rgb_frame_counter = 0
    Var.snake_rgb_last_frame = -2

    Var.music_frisk_index = random.randint(0, len(Var.music_frisk) - 1)
    Var.music_index = random.randint(0, len(Var.music_game) - 1)

    Var.previous_keys = pygame.key.get_pressed()

async def main():
    Utility.load_game_data()
    Var.poison_streak_goal = random.randint(2, 5)
    Music.initialize_music()
    Music.set_volume((0 if Var.mute_music else Var.volume/100), (0 if Var.mute_sfx else Var.volume/100))
    Settings.initialize_sliders()

    with gzip.open(Utility.resource_path("Assets/Bad_Apple_RLE.gz"), "rt", encoding="utf-8") as f:
        raw_video_string = f.read()

        current_number = ""
        decoded_string = []
        for char in raw_video_string:
            if char.isdigit():
                current_number += char 
                continue

            count = int(current_number)
            pixel = "0" if char == "A" else "1"
            decoded_string.append(pixel * count)
            current_number = ""

        decoded_string = "".join(decoded_string)
        Var.bad_apple_frame = [
                decoded_string[i : i + Var.bad_apple_cols * Var.bad_apple_rows] 
                for i in range(0, len(decoded_string), Var.bad_apple_cols * Var.bad_apple_rows)
            ]

    Music.settings()

    TitleScreen.initialize()
    while Var.title_screen:
        TitleScreen.title_screen()
        await asyncio.sleep(0)

    while Var.settings:
        Settings.settings()
        await asyncio.sleep(0)

    while True:
        Utility.save_game_data()
        init_()
        Music.main_game()

        while Var.running:
            Running.running()
            await asyncio.sleep(0)
        if not Var.win_the_game:
            Var.loss += 1

        if Var.title_screen:
            Music.settings()
            TitleScreen.initialize()
            while Var.title_screen:
                TitleScreen.title_screen()
                await asyncio.sleep(0)
            while Var.settings:
                Settings.settings()
                await asyncio.sleep(0)
            continue

        await asyncio.sleep(0)
        if not Var.gamepause:
            Retry.render()
            while Var.retry:
                Retry.retry()
                await asyncio.sleep(0)

        if Var.title_screen:
            Music.settings()
            TitleScreen.initialize()
            while Var.title_screen:
                TitleScreen.title_screen()
                await asyncio.sleep(0)
            while Var.settings:
                Settings.settings()
                await asyncio.sleep(0)
            continue

        Music.settings()

        while Var.settings: 
            Settings.settings()
            await asyncio.sleep(0)

        Utility.save_game_data()
        if Var.title_screen:
            Music.settings()
            TitleScreen.initialize()
            while Var.title_screen:
                TitleScreen.title_screen()
                await asyncio.sleep(0)
            while Var.settings:
                Settings.settings()
                await asyncio.sleep(0)
            continue

        await asyncio.sleep(0)

    Music.pause()
    pygame.quit()

asyncio.run(main())