import pygame
import Var
import States.Music as Music
import random
import Utility
import Render

def initialize():
    # Var.TILE_HEIGHT = 20
    # Var.TILE_WIDTH = 25
    Var.score = -2
    Var.TILE_SIZE = min(500//(Var.TILE_HEIGHT + 3), 600//(Var.TILE_WIDTH + 3))
    Var.top_indent = (500 - Var.TILE_HEIGHT * Var.TILE_SIZE) // 2 - round(3/2 * Var.TILE_SIZE)
    Var.left_indent = (600 - Var.TILE_WIDTH * Var.TILE_SIZE) // 2 - round(3/2 * Var.TILE_SIZE)
    snake_init_x = 1
    snake_init_y = 1
    Var.snake_body = []

    for i in range(0, Var.TILE_HEIGHT - 2):
        if (i % 2 == 0):
            for j in range(0, Var.TILE_WIDTH):
                Var.snake_body.append([snake_init_x + j, snake_init_y + i])
                Var.score += 1
            continue
        for j in range(Var.TILE_WIDTH - 1, -1, -1):
            Var.snake_body.append([snake_init_x + j, snake_init_y + i])
            Var.score += 1
    i += 1
    Var.snake_body.append([snake_init_x + j, snake_init_y + i])
    Var.apple_array = []
    Var.apple_x = 1
    while Var.apple_x <= Var.TILE_WIDTH:
        Var.apple_y = 1
        while Var.apple_y <= Var.TILE_HEIGHT:
            Var.apple_array.append([Var.apple_x, Var.apple_y])
            Var.apple_y += 1
        Var.apple_x += 1

    filter_apple = [apple for apple in Var.apple_array if apple not in Var.snake_body]

    apple = random.choice(filter_apple)

    Var.apple_x = Var.snake_body[-1][0]
    Var.apple_y = Var.snake_body[-1][1]

    for i in range(6, 0, -1):
        Var.apple_x = Var.snake_body[-1][0] - i
        if Var.apple_x > 1 and [Var.apple_x, Var.apple_y] not in Var.snake_body:
            break
    else:
        Var.apple_x = apple[0]
        Var.apple_y = apple[1]
    Utility.update_skin(Var.snake_skin)

    Render.render_background()

    s = pygame.Surface((Var.SCREEN_WIDTH, Var.SCREEN_HEIGHT - 100))  # the size of your rect
    s.set_alpha(50)                # alpha level
    s.fill((0, 0, 0))           # this fills the entire surface
    Var.screen.blit(s, (0, 0))
    Var.screen.blit(pygame.transform.gaussian_blur(Var.screen, 3), (0, 0))
    text_title_screen_x = Var.SCREEN_WIDTH / 2
    text_title_screen_y = Var.SCREEN_HEIGHT / 3 + 30

    font_title_screen = pygame.font.Font('freesansbold.ttf', 50)

    text_title_screen = font_title_screen.render('SNAKE GAME', True, (255, 255, 255))

    dxy = [(1, 0), (-1, 0), (0, 1), (0, -1), (1, 1), (1, -1), (-1, 1), (-1, -1)]

    margin = 3
    for i in range(8):
        text_title_screen = font_title_screen.render('SNAKE GAME', True, (0, 100, 0))
        textRect_title_screen = text_title_screen.get_rect()
        textRect_title_screen.center = (text_title_screen_x + dxy[i][0] * margin, text_title_screen_y + dxy[i][1] * margin)
        Var.screen.blit(text_title_screen, textRect_title_screen)

    text_title_screen = font_title_screen.render('SNAKE GAME', True, (255, 255, 255))
    textRect_title_screen = text_title_screen.get_rect()
    textRect_title_screen.center = (text_title_screen_x, text_title_screen_y)
    Var.screen.blit(text_title_screen, textRect_title_screen)
    pygame.draw.rect(Var.screen, (0, 140, 0), (Var.SCREEN_WIDTH/2 - 110, 280, 100, 40))
    pygame.draw.rect(Var.screen, (0, 140, 0), (Var.SCREEN_WIDTH/2 + 10, 280, 100, 40))
    # pygame.draw.rect(Var.screen, (0, 140, 0), (Var.SCREEN_WIDTH/2 + 60, 280, 100, 40))

    font = pygame.font.Font('freesansbold.ttf', 20)
    option1 = font.render('Play', True, (255, 255, 255))
    option2 = font.render('Settings', True, (255, 255, 255))
    Var.screen.blit(option1, (Var.SCREEN_WIDTH/2 - 80, 290))
    Var.screen.blit(option2, (Var.SCREEN_WIDTH/2 + 18, 290))
    # option3 = font.render('Quit', True, (255, 255, 255))
    # Var.screen.blit(option3, (Var.SCREEN_WIDTH/2 + 88, 290))

    font_high_score = pygame.font.Font('freesansbold.ttf', 25)
    high_score_str = f'HIGH SCORE: {Var.highScore}'

    base_x = Var.SCREEN_WIDTH - 20
    base_y = 20
    
    margin = 2 

    text_outline = font_high_score.render(high_score_str, True, (100, 100, 100))
    for dx, dy in dxy:
        rect_outline = text_outline.get_rect()
        rect_outline.topright = (base_x + (dx * margin), base_y + (dy * margin))
        Var.screen.blit(text_outline, rect_outline)

    text_main = font_high_score.render(high_score_str, True, (255, 255, 255))
    rect_main = text_main.get_rect()
    rect_main.topright = (base_x, base_y)
    Var.screen.blit(text_main, rect_main)

    pygame.display.flip()


def title_screen():
    for event in pygame.event.get():
        if event.type == pygame.MOUSEBUTTONDOWN:
            if 280 <= event.pos[1] <= 320:
                if Var.SCREEN_WIDTH/2 - 110 <= event.pos[0] <= Var.SCREEN_WIDTH/2 - 10:
                    Music.click()
                    Var.running = True
                    Var.retry = False
                    Var.title_screen = False
                    

                elif Var.SCREEN_WIDTH/2 + 10 <= event.pos[0] <= Var.SCREEN_WIDTH/2 + 110:
                    Music.click()
                    Var.settings = True
                    Var.running = True
                    Var.retry = False
                    Var.title_screen = False
                    
                # elif Var.SCREEN_WIDTH/2 + 60 <= event.pos[0] <= Var.SCREEN_WIDTH/2 + 160:
                #     Music.click()
                #     Var.running = False
                #     Var.retry = False
                #     Var.title_screen = False

        if event.type == pygame.KEYDOWN:
            Var.history_keys_pressed.append(event.key)
            if Var.history_keys_pressed[-10:] == Var.snake_rgb_key_code:
                Var.snake_rgb = not Var.snake_rgb
                if Var.snake_epilepsy: 
                    Var.snake_epilepsy = False
                    Var.history_keys_pressed.append(-1)
            if Var.history_keys_pressed[-30:] == Var.snake_rgb_key_code * 3:
                Var.history_keys_pressed.append(-1)
                Var.snake_epilepsy = not Var.snake_epilepsy
        #     if event.key == pygame.K_ESCAPE:
        #         Var.running = False
        #         Var.retry = False
        #         Var.settings = False
        #     if event.key == pygame.K_ESCAPE:                                
        #         Var.running = False
        #         Var.retry = False
        #         Var.settings = False
        #         Var.title_screen = False
        # if event.type == pygame.QUIT:
        #     Var.running = False
        #     Var.retry = False
        #     Var.settings = False
        #     Var.title_screen = False
